-- fxSvgViewer (Node.js version)
-- (c) Valentin Schmidt 2016

A simple SVG Viewer based on:

 - Node.js v0.8.25 (http://nodejs.org/)
 - Node-Qt (http://valentin.dasdeck.com/js/node_qt/) 
 - Qt v4.7.4 (http://qt.apidoc.info/4.7.4/)

License: WTFPL 2.0

You can find a published standalone version for Windows at:
http://valentin.dasdeck.com/projects/scite_sidebar/published_projects/
