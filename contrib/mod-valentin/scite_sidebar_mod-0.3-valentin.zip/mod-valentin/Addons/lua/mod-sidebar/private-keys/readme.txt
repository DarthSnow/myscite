For SFTP-access to servers with key file based authentication, put your private
key files (*.ppk) into this folder and add the line "key=<whatever>.ppk" to the
corresponding account section in ftp.ini.